$(document).ready(function () {
  $("#form").submit(function (e) {
    e.preventDefault();
    var regex = /^[a-zA-Z ]*$/;
    const formData = new FormData($("#form"));
    console.log(formData.get("email"));
  });
});
